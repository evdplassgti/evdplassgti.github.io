﻿<#
checkLiquitConfig.ps1
Copyright (C) 2022 Sogeti Nederland B.V.

Check the configuration of Liquit Workspace.

.SYNOPSIS
This script checks the configuration of Liquit Workspace implementations against best practices and standards.

.Description
The scripts first connects to Liquit Workspace using the Liquit PowerShell module. Different aspects in the configuration are checked against best practices,
standards and misconfiguration.

.CHANGELOG
VERSION  DATE               AUTHOR               DESCRIPTION
-------- ------------------ -------------------- ---------------------------------------------------------------------------------
   1.0.0 December 18, 2021  Ronald Bakker        First version
   1.1.0 December 22, 2021  Ronald Bakker        Extended with confguration in json
   1.1.1 January 3, 2022    Ronald Bakker        Extended with checks for Access Policies
   
#>

param(
     [Parameter(Mandatory)]
     [string]$LiquitZone,
     [Parameter(Mandatory)]
     [string]$jsonPath
     )

[string]$logFile="${Env:Temp}\checkLiquitConfig.log"
[string]$LiquitModulePath = "${Env:ProgramFiles(x86)}\Liquit Workspace\PowerShell\3.0\Liquit.Server.PowerShell.dll"
[int[]]$numNotification=@(0,0,0,0,0)

function Write-Log() {
    Param ([int]$Severity,
           [string]$logText)
    
    [string[]]$LogType=@(""," (Information) "," (Warning) "," (Error) ","##### ")
    
     Switch ($Severity) {
     
     0        {
                Write-Output $logText
                Add-content $logFile -value $logText
              }

     4        {
                Write-Output ($logtype[$severity] + $logText)
                Add-content $logFile -value ($($logtype[$severity]) + $logText)
              }
     

     default {
                Write-Output ($logtype[$severity] + $logText)
                $Now=Get-Date -Format "dd/MM/yyyy HH:mm:ss"
                Add-content $logFile -value ($Now + $($logtype[$severity]) + $logText)
                $NumNotification[$Severity]++
                $NumNotification[4]++
            }
    }
}

function getConfiguration() { 
      
    #Test if inputfile exists
    if (!(Test-Path $jsonPath)) {
      Write-Log  3 "Input json file $jsonPath does not exist."
      Exit
    }

    #Open inputfile
    Try {
        $jsonContent=(Get-Content $jsonPath | ConvertFrom-Json)
    }
    Catch {
        Write-Log 3 "There is a problem opening the json file with the standard configuration ($jsonPath)."
        Exit
    }

    return $jsonContent
}    

function ConnectLiquit()
{
    param([string]$liqURL)

    if ($LiqURL.StartsWith("https://")) {
      $LiquitURL=$liqURL 
    }
    else {
      $LiquitURL="https://" + $liqURL
    }

    # Import Liquit PowerShell module
    
    # Verify if we can find the module in the working directory.
    if (-not (Test-Path $LiquitModulePath)) {

	    # Try to find the path of this script.
	    if ($MyInvocation.MyCommand.Source){
		  $LiquitModulePath = (split-path -parent $MyInvocation.MyCommand.Definition) + "\Liquit.Server.PowerShell.dll"
	    }
	
	    # Verify the new module path.
	    if (-not (Test-Path $LiquitModulePath))	{
		  Write-Log 3 "Unable to find 'Liquit.Server.PowerShell.dll', please verify the path."
          Exit
	    }
    }

    # Load Liquit PowerShell Module
    Try {
       Import-Module $LiquitModulePath -Prefix "Liquit"}
    Catch {
       Write-Log 3 "Cannot import Liquit PowerShell module."
       Exit
    }

    # Connect to Liquit Workspace
    Write-Log 0 "Connecting to $LiquitURL"
    Try {
        $liquitContext = Connect-LiquitWorkspace -URI $LiquitURL -Credential (Get-Credential)
        Write-Log 0 "Connection to Liquit Workspace successfully established.`n"
    }
    catch {
        Write-Log 3 "Cannot connect to Liquit Workspace on URL $LiquitURL."
        Exit
    }
}

function getOrphanedEntitlements() {

param($pkg)

        Try {
          $pkgEntitlements=Get-LiquitPackageEntitlement -Package $pkg

            if (!$pkgEntitlements) {
                Write-Log 2 "Package '$($pkg.Name)' [$($pkg.id)] has no entitlements."
            }

            ForEach ($pkgEntitlement in $pkgEntitlements) {
          
                Try {
                    $pkgIdenity=Get-LiquitIdentity -id $pkgEntitlement.id -ErrorAction Stop
                }
                Catch {
                    Write-Log 3 "Identity $($pkgEntitlement.id) for package '$($pkg.Name)' [$($pkg.id)] no longer exists."
                }
            }
        }
        Catch {
            Write-Log 2 "Error retrieving entitlements for package '$($pkg.Name)' [$($pkg.id)]."
        }

}

function checkActionSets() {

param($pkg)
[int]$EnabledAS=0

    Try {
        $snapShot=Get-LiquitPackageSnapshot -package $pkg -type 'Production'
        if (!$snapshot) {
            Write-Log 1 "Package '$($pkg.Name)' [$($pkg.id)] has no Production snapshot."
            Return
        }
    }
    Catch {
        Write-Log 1 "Package '$($pkg.Name)' [$($pkg.id)] has no Production snapshot."
        Return
    }

    Try {
        $actionSets=Get-LiquitActionSet -Snapshot $snapshot
        if (!$actionSets) { 
            Write-Log 3 "Package '$($pkg.Name)' [$($pkg.id)] has no ActionSet and is published to Production."
            Return
        }
    }
    Catch {
        Write-Log 3 "Package '$($pkg.Name)' [$($pkg.id)] has no ActionSet and is published to Production."
        Return
    }

    
    ForEach ($actionSet in $actionSets) {
      if ($actionSet.Enabled) {$EnabledAS++}
      Try {
        $actions=Get-LiquitAction -ActionSet $actionset
        if (!$actions) {
            Write-Log 3 "Package '$($pkg.Name)' [$($pkg.id)] has an ActionSet without Actions [ActionSet $($actionSet.Name)]."
        }
      }
      Catch {
         Write-Log 3 "Package '$($pkg.Name)' [$($pkg.id)] has one or more invalid Actions [ActionSet $($actionSet.Name)]."
      }
    }

    if ($EnabledAS -lt 1) {
      Write-Log 3 "Package '$($pkg.Name)' [$($pkg.id)] has an ActionSet but none is enabled and the package is published to Production."
    }

}

function ProcessIdentitySources() {

[int]$intAAD=0
[int]$intVisible=0
[bool]$AADVisible=$False

    Write-Log 4 "Check identitySources."
    $issues=$numNotification[4]

    # At least one identitySource of type AzureAD should exist (enabled) and only one identitySource should be visible
    Try {
        $identitySources=Get-LiquitIdentitySource
        ForEach ($identitySource in $identitySources) {

          if (!$identitySource.Enabled) {
              Write-Log 2 "IdentitySource '$($identitySource.Name)' of type $($identitySource.Type) is not enabled."
          }
          else {
            if (!$identitySource.Hidden) {$intVisible++}
            if ($identitySource.Type -eq 'azuread') {
                $intAAD++
                $AADVisible=(!$identitySource.Hidden)
            }
          }
        }

        if ($intAAD -eq 0) {
          Write-Log 3 "No identitySource of type AzureAD exists or is enabled"
        }

        if ($intVisible -ne 1) {
          Write-Log 3 "(Only) one identitySource should be visible, currently $intVisible identitySources are visible."
        }

        if (!$AADVisible) {
          Write-Log 3 "The AzureAD identitySource should be visible for end users to login."
        }

    }
    Catch {
        Write-Log 3 "Retrieving identity sources failed."
        $identitySources=$null
    }

    if ($issues -eq $numNotification[4]) {
      Write-Log 0 " No issues found"
    }

    Write-Log 0
    
}

function CheckSettings() {

param ($liqSettings)

    Write-Log 4 "Check Portal, User and Login Settings."

    ForEach ($liqSetting in $liqSettings) {
        $id=$liqSetting.id
        Try {
            $setting=(Get-LiquitSetting -id $id).Value
            if ($setting -ne $liqSetting.value) {
                Write-Log 3 "Setting '$id' is not properly configured. Detected value [$setting], expected [$($liqSetting.value)]."
            }
        }
        Catch {
            WriteLog 2 "Cannot retrieve setting '$id'"
        }
    }
    
    if ($issues -eq $numNotification[4]) {
      Write-Log 0 " No issues found"
    }

    Write-Log 0

}

function CheckSecuritySettings() {

param($settings)

    Write-Log 4 "Check Security Settings in the zone."

    $issues=$numNotification[4]

    $Zone=Get-LiquitZone

    if ($Zone.HstsEnabled -ne $settings.HstsEnabled) {
      Write-Log 3 "Incorrect setting 'Send HSTS Header'. Configured value '$($zone.HstsEnabled)', expected value $($settings.HstsEnabled)."
    }
    if ($zone.HstsMaxAge -ne $settings.HstsMaxAge) {
      Write-Log 3 "Incorrect setting 'HSTS Max Age'. Configured value '$($zone.HstsMaxAge)', expected value $($settings.HstsMaxAge)."
    }
    if ($zone.CspEnforce -ne $settings.CspEnforce) {
      Write-Log 3 "Incorrect setting 'Content Security Policy (CSP)'. Configured value '$($zone.CspEnforce)', expected value $($settings.CspEnforce)."
    }  
    if ($zone.CspForceSecure -ne $settings.CspForceSecure) {
      Write-Log 3 "Incorrect setting 'Upgrade insecure requests and enforce HTTPS schema'. Configured value '$($zone.CspForceSecure)', expected value $($settings.CspForceSecure)."
    }
    
    $CspFrameSites=$Zone.CspFrameSites
    ForEach ($CspFrameSite in $CspFrameSites) {
      if (!($settings.CspFrameSites.Contains($CspFrameSite))) {
        Write-Log 3 "Missing '$CspFrameSite' in the list of websites allowed to embed the zone."
      }
    }
    
    if ($zone.CorsAuthEnabled -ne $settings.CorsAuthEnabled) {
      Write-Log 3 "Incorrect setting 'Cross Origing Authentication (Cors)' Configured value '$($zone.CorsAuthEnabled)', expected value $($settings.CorsAuthEnabled)."
    }

    $CorsAuthSites=$Zone.CorsAuthSites
    ForEach ($CorsAuthSite in $CorsAuthSites) {
      if (!($settings.CorsAuthSites.Contains($CorsAuthSite))) {
        Write-Log 3 "Missing '$CorsAuthSite' in the list of websites allowed to authenticate against the zone."
      }
    }

    if ($issues -eq $numNotification[4]) {
      Write-Log 0 " No issues found"
    }

    Write-Log 0
}

function CheckServers() {

$version=""
$bVersionDiffers=$false
$issues=0

    Write-Log 4 "Check Server configuration in the zone."
    $issues=$numNotification[4]

    Try {
        $liqServers=Get-LiquitServer
        forEach ($liqServer in $liqServers) {
            if ($Version -eq "") {
                $version=$liqServer.Version
            }
            else {
                if ($liqServer.Version -ne $Version) {
                    $bVersionDiffers=$True
                }
            }
            if ($liqServer.Version -lt $reqLiquitVersion) {
                Write-Log 3 "Server $($liqServer.Name) is not up to date. Reported version $($liqServer.Version), required version $reqLiquitVersion"
            }
        }

        if ($bVersionDiffers) {
            Write-Log 3 "Servers are configured with different versions. Update the servers to have the same version of Liquit Workspace."
        }
    }
    Catch {
        Write-Log 3 "cannot retreive server configuration."
    }

    if ($issues -eq $numNotification[4]) {
      Write-Log 0 " No issues found"
    }

    Write-Log 0
}

function CheckAccessPolicy() {

  param([string]$policyName,
        [string[]]$definedPrivs)

    Try {
        $accessPolicy=(Get-LiquitAccessPolicy -Type Role)|Where-Object {$_.Name -eq "$policyName"}
    }
    Catch {
        $accessPolicy=""
        Write-Log 2 "$policyName Role Access Policy not found"
    }

    if ($accessPolicy) {
        
        [int]$Deviations=0
        $ConfiguredPrivs=$accessPolicy.Privileges

        #Check if all configured privileges are also in defined role
        ForEach ($Priv in $ConfiguredPrivs) {
          if (!$definedPrivs.Contains($Priv)) {
            Write-Log 3 "Privilege $Priv is configured but not in Access Policy definition. Privilege should be removed."
            $Deviations++
          }
        }
        #Check if all defined privileges are also configured
        ForEach ($Priv in $definedPrivs) {
          if (!$ConfiguredPrivs.Contains($Priv)) {
            Write-Log 3 "Privilege $Priv is in Access Policy definition but not configured. Privilege must be added."
            $Deviations++
          }
        }

        if ($Deviations -eq 0) {
            Write-Log 0 " No deviations found in '$policyName' Access Policy definition."
        }

        $Permissions=(Get-LiquitPermission|Where-Object {$_.AccessPolicy.Name -eq "$policyName"})
        if (!$Permissions) {
          Write-Log 2 "'$policyName' Access Policy is not assigned to a user or a group."
        }
    }

}

function processChecks() {


    #Process packages
    $Packages=(Get-LiquitPackage)
    $issues=$numNotification[4]

    Write-Log 4 "Check packages for consistency."
    ForEach ($package in $packages) {

        getOrphanedEntitlements $package
        if ($package.Enabled -eq $False) {
           Write-Log 1 "Package $($package.Name) [$($package.id)] is not enabled. Consider removing the package."
        }
        checkActionSets $package
    }

    if ($issues -eq $numNotification[4]) {
      Write-Log 0 " No issues found"
    }
      
    Write-Log 0

    #Process identitySources   
    ProcessIdentitySources

    #Check Portal Settings
    $settings=$defaultConfig|Select-Object -Expand Settings
    CheckSettings($settings)

    #Check Zone Settings
    $settings=$defaultConfig|Select-Object -Expand Security
    CheckSecuritySettings($settings)

    #Check Server(s)
    CheckServers

    #Check Access Policy
    Write-Log 4 "Check Access Policies in the zone."
    $settings=$defaultConfig|Select-Object -Expand Roles
    ForEach ($Role in $settings) {
      $PolicyName=$Role.name
      $Privileges=$Role.privileges
      CheckAccessPolicy -policyName $PolicyName -definedPrivs $Privileges
    }
    Write-Log 0
}

Write-Log 4 "Starting check for Liquit Workspace zone $LiquitZone`n"

#Read the configuration json file
 $defaultConfig=getConfiguration
#Connect to Liquit Workspace
 connectLiquit($LiquitZone)
#Process the checks
 processChecks
#End
 Write-Log 4 "Liquit Configuration check completed.`n"
 Write-Log 0 "---- -------------------------------------"
 $text=" {0,3} Informational notifications" -f $($numNotification[1])
 Write-Log 0 $text
 $text=" {0,3} Warnings" -f $($numNotification[2])
 Write-Log 0 $text
 $text=" {0,3} Errors" -f $($numNotification[3])
 Write-Log 0 $text
 Write-Log 0 "---- -------------------------------------"
 $text=" {0,3} Total notifications" -f $($numNotification[4])
 Write-Log 0 $text
 Write-Output "`n Logfile can be found here: $LogFile"