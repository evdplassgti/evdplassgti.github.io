﻿<#
initLiquit.ps1
Copyright 2021 Sogeti Nederland B.V.

Initial configuration for Liquit Workspace in SSW.

.SYNOPSIS
This script does the initial configuration for the Application Portal in Sogeti Smart Workspace.

.Description
The scripts first connects to Liquit Workspace using the Liquit PowerShell module. 
It then does the following, initial configuration:

- Create base applications for SSW (like Office, Adobe Reader, 7-Zip, etc).
- Creation of standard roles
- Security Settings
- Credential templatefor AzureAD account in the Credential Store
- Base configuration for Portal, User and Login

.Input

.Parameters
The following parameters are used by the script:
- jsonPath                           Mandatory. Full path to a json file containing the configuration for initial setup
- LiquitZone                         Optional, Zone for the Liquit Workspace environment. Change this for your environment, defaults to Sogeti Test environment.

.Output
The scripts generates the following output
- A Liquit package for each line item in the json
- Initial security configuration
- Initial configuration for portal, login and users
- Credential for use in packages, based on Azure AD UPN
- Standard roles (Reader, Level 1 and Level 2-3)
- A logfile in the temp folder (%TEMP%\initLiquit.log).

.CHANGELOG
VERSION  DATE               AUTHOR               DESCRIPTION
-------- ------------------ -------------------- ---------------------------------------------------------------------------------
   1.0.0 December 20, 2021  Ronald Bakker        First Version
   1.0.1 December 21, 2021  Ronald Bakker        Improved error handling
   
#>

param(
     [Parameter(Mandatory)]
     [string]$jsonPath,
     [Parameter(Mandatory)]
     [string]$LiquitZone
     )

[string]$logFile="${Env:Temp}\initLiquit.log"
[string]$LiquitModulePath = "${Env:ProgramFiles(x86)}\Liquit Workspace\PowerShell\3.0\Liquit.Server.PowerShell.dll"

function Write-Log() {
    Param ([string]$logText)
    
     if ($logText -eq "<blank>") {
        Add-content $logFile -value ""
     }
     else {
        Write-Output $logText
        $Now=Get-Date -Format "dd/MM/yyyy HH:mm:ss "
        $logText=$Now + $logText
        Add-content $logFile -value $logText
    }
}    

function getConfiguration() { 
      
    #Test if inputfile exists
    if (!(Test-Path $jsonPath)) {
      Write-Log "Input json file $jsonPath does not exist."
      Exit
    }

    #Open inputfile
    Try {
        $jsonContent=(Get-Content $jsonPath | ConvertFrom-Json)
    }
    Catch {
        Write-Log "There is a problem opening the json file with the standard configuration ($jsonPath)."
        Exit
    }

    return $jsonContent
}

function ConnectLiquit()
{
    param([string]$Zone)

    if ($Zone.StartsWith("https://")) {
      $LiquitURL=$Zone 
    }
    else {
      $LiquitURL="https://" + $Zone
    }

    # Import Liquit PowerShell module
    
    # Verify if we can find the module in the working directory.
    if (-not (Test-Path $LiquitModulePath)) {

	    # Try to find the path of this script.
	    if ($MyInvocation.MyCommand.Source){
		  $LiquitModulePath = (split-path -parent $MyInvocation.MyCommand.Definition) + "\Liquit.Server.PowerShell.dll"
	    }
	
	    # Verify the new module path.
	    if (-not (Test-Path $LiquitModulePath))	{
		  Write-Log "Error: Unable to find 'Liquit.Server.PowerShell.dll', please verify the path."
          Exit
	    }
    }

    # Load Liquit PowerShell Module
    Try {
       Import-Module $LiquitModulePath -Prefix "Liquit"}
    Catch {
       Write-Log "Error: Cannot import Liquit PowerShell module."
       Exit
    }

    # Connect to Liquit Workspace
    Write-Log "Connecting to $LiquitURL"
    Try {
        $liquitContext = Connect-LiquitWorkspace -URI $LiquitURL -Credential (Get-Credential)
        Write-Log "Success: Connection to Liquit Workspace successfully established."
    }
    catch {
        Write-Log "Error: Cannot connect to Liquit Workspace on URL $LiquitURL."
        Exit
    }
}

function CreateCredential() {

param($Credentials)

    Write-Log "#### Configuring Credentials Store."

    ForEach ($Credential in $Credentials) {

      if (!(Get-LiquitCredential|Where-Object {$_.Name -eq $Credential.Name})) {

        if ($Credential.Type -eq "Template") {
            Try {
                New-LiquitCredential -Name $Credential.Name -Template `
                    -UserName $Credential.Username `
                    -Description $Credential.Description `
                    -Verify $Credential.Verify
                Write-Log "Information: New Credential $($Credential.Name) created succesfully."
            }
            Catch {
                Write-Log "Error: Creation of credential $($Credential.Name) failed."
            }
         }
      }
      else {
        Write-Log "Information: New Credential '$($Credential.Name)' already exists, skipped creation."
      }
    }

    Write-Log "#### Configuring of credentials in the Credentials Store completed."
}

function configureSecurity() {

param($security)

    Write-Log "#### Configuring Security Settings in the zone."

    if ($LiquitZone.StartsWith("https://")) {
      $liqZone=$LiquitZone.Substring(8)
      Write-Log "Warning: Liquit Zone parameter starts with https://. Assuming zone is the domain part in the URL."
    }
    else {
      $liqZone=$LiquitZone
    }

    Try {
        $Zone=Get-LiquitZone|Where-Object {$_.VirtualHost -eq $LiqZone}
    }
    Catch {
        Write-Log "Error: Cannot find zone with VirtualHost $LiqZone."
        Exit
    }

    if (!$Zone) {
        Write-Log "Error: Cannot find zone with VirtualHost $LiqZone."
        Exit
    }

    Try {
      Set-LiquitZone -Zone $Zone `
            -HstsEnabled $security.HstsEnabled `
            -HstsMaxAge $security.HstsMaxAge `
            -HstsPreload $security.HstsPreload `
            -HstsIncludeSubDomains $security.HstsIncludeSubDomains `
            -CspEnforce $security.CspEnforce `
            -CspReporting $security.CspReporting `
            -CspForceSecure $security.CspForceSecure `
            -CspFrameSites $security.CspFrameSites `
            -CorsAuthEnabled $security.CorsAuthEnabled `
            -CorsAuthSites $security.CorsAuthSites

      Write-Log "Information: Security Settings in the zone successfully applied.`n"
    }
    Catch {
        Write-Log "Error: Cannot set security configuration for zone with VirtualHost $LiqZone."
        Exit
    }
    
}

function CreateApps() {

 param($packages)

 [int]$counter=0

    Write-Log "#### Create standard packages."

    ForEach ($Package in $Packages){

        $counter++
        Write-Log "Processing package: - $counter -"

        #Define variables from record in json
        $pkgName = $Package.Name
        $pkgType = $Package.Type
        $pkgGroupName = $Package.Group
        $pkgIconPath = $iconRoot + $Package.Icon
        if ($pkgIconPath -eq '') {
          $pkgIconPath=$DefaultIcon
        }
        elseif (!(Test-Path $pkgIconPath)) { 
            $pkgIconPath=$DefaultIcon
        }
       
        # Create package and entitlement, publish to production
        # All required variables should contain a value, the package must not already exist and the group must exist

        if (($pkgName -ne '') -and ($pkgGroupName -ne ''))
        {
            #Check if package already exists, if not then create new package         
            if (!(Get-LiquitPackage|Where-Object {$_.Name -eq "ssw-$pkgName"})) {

                #Check if Group for entitlement exists
                $Identity=Get-LiquitIdentity -Type Group|Where-Object {$_.DisplayName -eq $pkgGroupName}
                
                if ($Identity -ne $null) {
                  Try {
                    $Notes="Autocreated by Sogeti Smart Workspace " + (Get-Date -Format "dd/MM/yyyy HH:mm:ss")
                    $NewPkg=New-LiquitPackage -Name "ssw-$pkgName" -Type $pkgType -DisplayName $pkgName -Web ($pkgType -eq "Web") -Icon (New-LiquitContent -Path $pkgIconPath) -Offline ($pkgType -eq "Web") -Notes $Notes
                    $SnapShot = New-LiquitPackageSnapshot -Package $NewPkg
                    $ActionSet = New-LiquitActionSet -Snapshot $Snapshot -Name $pkgName -Enabled $True  -Process StopAtFirstEffectiveAction -Type Launch
                    ForEach ($Action in $Package.Actions) {
                        if ($Action.Type -eq "OpenURL") {
                            $Action = New-LiquitAction -ActionSet $ActionSet -Name $Action.Name -Type $Action.Type -Enabled $True -IgnoreErrors $False -Settings @{url=$Action.Target; browser=0; needAuthSession=$false; forcePrivate=$false}
                        }
                        else {
                            $Action = New-LiquitAction -ActionSet $ActionSet -Name $Action.Name -Type $Action.Type  -Settings @{name=$Action.Target} -Context User -Enabled $True -IgnoreErrors $True
                        }
                    }
                    New-LiquitPackageEntitlement -Package $NewPkg -Identity $Identity -Publish Workspace -stage Production
                    Publish-LiquitPackageSnapshot -Snapshot $Snapshot -Stage 'Production'
                    Write-Log " Succes: Package '$pkgName' created successfully."
                  }
                  Catch {
                    Write-Log " Error creating package $pkgName".
                  }
                }
                else {
                  Write-Log " Error: Group '$pkgGroupName' does not exist, skipping package '$pkgName'."
                }              
            }
            else {
                Write-Log " Warning: a package with the name '$pkgName' already exists. Skipping this package."
            }
         }
         else {
            Write-Log " Error: record incomplete. Name: $pkgName, Target:$pkgTarget, Group:$pkgGroupName."
        }
        
    }
    Write-Log "Processed $counter package(s)."
    Write-Log "#### Package creation completed.`n"
}

function ConfigureSettings() {

param($settings)

    Write-Log "#### Configure standard settings."

    ForEach ($setting in $settings) {
      Try {
        $liqSetting = Get-LiquitSetting -id $setting.id
        Set-LiquitSetting -Setting $liqSetting -Value $setting.Value -Force $setting.Force
        Write-Log "Setting '$($setting.id)' configured."
      }
      Catch {
        Write-Log "Error: Configuration of setting '$($setting.id)' failed."
      }
    }

    Write-Log "#### Configuration of standard settings completed."
}

function SetAccessPolicy() {

  param([string]$policyName,
        [string[]]$definedPrivs)

    Try {
        $accessPolicy=(Get-LiquitAccessPolicy -Type Role)|Where-Object {$_.Name -eq "$policyName"}
    }
    Catch {
        $accessPolicy=""
        Write-Log "Information: '$policyName' Role Access Policy not found"
    }

    if (!$accessPolicy) {
        Try {
            New-LiquitAccessPolicy -Role -Privileges $definedPrivs -Name "$policyName"
            Write-Log "Information: '$policyName' Role Access Policy created successfully."
            Write-Log "Assign '$policyName' Role to proper group."
        }
        Catch {
            Write-Log "Error: Configuration of '$policyName' Role Access Policy failed."
        }
    }
    else {
        [int]$Deviations=0
        $ConfiguredPrivs=$accessPolicy.Privileges

        #Check if all configured privileges are also in defined role
        ForEach ($Priv in $ConfiguredPrivs) {
          if (!$definedPrivs.Contains($Priv)) {
            Write-Log "Error: Privilege $Priv is configured but not in role definition. Privilege will be removed."
            $Deviations++
          }
        }
        #Check if all defined privileges are also configured
        ForEach ($Priv in $definedPrivs) {
          if (!$ConfiguredPrivs.Contains($Priv)) {
            Write-Log "Error: Privilege $Priv is in role definition but not configured. Privilege will be added."
            $Deviations++
          }
        }

        if ($Deviations -gt 0) {
            Try {
                Set-LiquitAccessPolicy -AccessPolicy $accessPolicy -Privileges $definedPrivs
                Write-Log "Error: Found $Deviations deviations in '$policyName' Access Policy which are corrected."
                Write-Log "Information: '$policyName' Role Access Policy updated successfully."
            }
            Catch {
                Write-Log "Error: Configuration of '$policyName' Role Access Policy failed."
            } 
        }
        else {
            Write-Log "Information: No deviations found in '$policyName' Access Policy."
        }
    }
}

function ConfigureRoles() {

param($Roles)

    Write-Log "<blank>"
    Write-Log "### Configure Role Access Policies"

    ForEach ($Role in $Roles) {
        SetAccessPolicy -policyName $Role.Name -definedPrivs $Role.Privileges
    }

    Write-Log "### Configuration of Role Access Policies completed."

}

#Define default icon variables
$iconRoot=(split-path -parent $MyInvocation.MyCommand.Definition) + "\icon\"
$DefaultIcon=(split-path -parent $MyInvocation.MyCommand.Definition) + "\icon\icon.png"
If (-not (Test-Path $DefaultIcon)) {
    Write-Log "Error: Default icon file does not exist ($DefaultIcon). Quitting."
    Exit
}

#Read the configuration json file
$defaultConfig=getConfiguration

#connect to the Liquit zone
connectLiquit($LiquitZone)

#Configure security settings
$settings=$defaultConfig|Select-Object -Expand Security
configureSecurity($settings)

#Create packages for the base apps
$settings=$defaultConfig|Select-Object -Expand Packages
CreateApps($settings)

#Configure a credential in the Credential Store
$settings=$defaultConfig|Select-Object -Expand Credentials
CreateCredential($settings)

#Configure standard settings in the portal
$settings=$defaultConfig|Select-Object -Expand Settings
configureSettings($settings)

#Create base roles (RBAC)
$settings=$defaultConfig|Select-Object -Expand Roles
configureRoles($settings)